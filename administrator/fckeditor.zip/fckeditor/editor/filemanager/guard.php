<?php

	session_start();
	if ( isset($_SESSION["login"]) && isset($_SESSION["password_hash"]) )
	{
		$uri_parts = explode("?", $_SERVER["REQUEST_URI"]);
		require_once($_SERVER["DOCUMENT_ROOT"].$uri_parts[0]);
	}

?>